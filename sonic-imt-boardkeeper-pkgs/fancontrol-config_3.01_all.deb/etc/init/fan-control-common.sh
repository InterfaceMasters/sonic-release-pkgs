#!/bin/sh

disable_fans_max_speed()
{
	if [ -e /sys/devices/board/primary/product ]
	then
		product=$(cat /sys/devices/board/primary/product)
	fi
	if [ "${product}" = "IM2748_TD3" ] ||
	   [ "${product}" = "IM2728" ] ||
	   [ "${product}" = "IM2624B" ];
	then
		module_path="/sys/devices/board"
		slot="ext00"
		for i in $(seq 0 1);
		do
			io_product=${module_path}/${slot}${i}/product
			if [ -e ${io_product} ]; then
				if [ $(cat ${io_product}) = "IM13251" ] ||
				   [ $(cat ${io_product}) = "IM13270" ];
				then
					misc_reg=${module_path}/${slot}${i}/cpld/MISC_CSR
					if [ -e ${misc_reg} ]; then
						echo 00 > ${misc_reg}
					else
						echo "Failed to find path ${misc_reg} on ${slot}${i}."
						return 1
					fi
				fi
			fi
		done
	else
		fc_reg=/sys/devices/board/fan/cpld/FC_SS
		if [ -e ${fc_reg} ]; then
			echo 00 > ${fc_reg}
		else
			echo "Failed to find ${fc_reg} on fan device."
			return 1
		fi
	fi
	return 0
}
