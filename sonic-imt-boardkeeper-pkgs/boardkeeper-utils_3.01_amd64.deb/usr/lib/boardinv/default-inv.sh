#!/bin/bash

INV_TEMPLATE_SCRIPT_PATH="/usr/lib/boardinv"
. $INV_TEMPLATE_SCRIPT_PATH/inv_template_prepare.sh
INV_TEMPLATE_IS_INTERACTIVE=0

function die() {
	echo $@
	exit 1
}

function is_inv_empty() {
	local dev=$1
	inventory_hex=$(hexdump -e '/1 "%02x "' /sys/bus/board/devices/boardbus:${dev}/ufm)
	if [ "$inventory_hex" = "ff *" ];
	then
		return 0
	fi
	return 1
}

function get_inv_var() {
    local var="$1"
    local inv="$2"
    local val=$(printf '%s' "$inv"|sed -e '/'"$var"'/ { s/^.*'"$var"'=//; q; }; d')
    echo -n $val | sed -re 's/^"(.*)"$/\1/'
}

# return 0 if UFM contains valid inventory
# return 1 if UFM is empty
# return 2 if UFM is not empty, and inventory is invalid
# return 3 if device does not exist
function check_device() {
	local dev=$1
	if ! [ -f /sys/bus/board/devices/boardbus:${dev}/ufm ]; then
		return 3
	fi
	if inv=$(inv_print -u 0x$dev) 2> /dev/null; then
		[ "$dev" != "9D" ] && return 0
		board=$(get_inv_var board_id "$inv")
		case "$board" in
		    IO_BCM_N2846)
			branch_ufm=$(get_inv_var branch_ufm "$inv")
			if [ "$branch_ufm" != "0x80 0x81 0x82 0x83 0x84 0x85 0x86 0x87 0x88 0x89 0x8a 0x8b 0x98 0x99" ]; then
			    return 1;
			fi
			;;
		esac
		iserial=$(get_inv_var serial "$inv")
		if [ -z "$iserial" -o "$iserial" == "1" ]; then
		    get_serial $dev
		    if [ -n "$serial" -a "$serial" != "1" ]; then
			return 1;
		    fi
		fi
		return 0
	fi
	if is_inv_empty $dev; then
		return 1
	fi
	return 2
}

function fixup_n32822e_primary() {
    local dev=$1
    product=$(</sys/bus/board/devices/boardbus\:${dev}/product)
    [ "$product" == "IM32822E" ] || return 0
    inv_print -U 0x${dev}|grep -q '\[io\]' || ((inv_print -U 0x9d; echo -e '[io]\n\tport_map=1G_FIBRE 1G_FIBRE 1G_FIBRE 1G_FIBRE') > /tmp/tt.inv && inv_create -n -c /tmp/tt.inv -f /tmp/tt.bin && inv_save -f /tmp/tt.bin)
    rm -f /tmp/tt.bin /tmp/tt.inv
}

function default_inv() {
	local dev=$1
	local product=$(</sys/bus/board/devices/boardbus:${dev}/product)
	local invsrc=$invdir/$product.inv
	local invtmp=/tmp/$product-$dev.inv
	local invbin=/tmp/$product-$dev.bin
	[ -f $invsrc ] || die "Inventory source for $product does not exist"
	get_serial $dev
	inv_template_clear_gvar
	inv_template_set_gvar "0x${dev}" "${product}" "${serial}"
	inv_template_prepare "${invsrc}" "${invtmp}"
	if [ "$?" -ne "0" ]; then
		die "Failed to prepare inventory sources for $product on CPLD 0x${dev}"
	fi
	inv_create -n -c $invtmp -f $invbin
	inv_save -f $invbin
}

function get_serial() {
    serial="1"
    if [ "$1" == 9D ]; then
	eval $(dmidecode -t 3|sed -nre '/Manufacturer/{s/^.*: (.*)$/MFG="\1";/;  p;}; /Serial/{s/^.*: (.*)$/SERIAL="\1";/;  p;};')
	if [ "$MFG" == "Interface Masters" ]; then
	    if [ -n "$SERIAL" ]; then
		serial="$SERIAL"
	    fi
	fi
    fi
}

invdir="$INV_TEMPLATE_SCRIPT_PATH"

dev=00
[ -n "$1" ] && dev=$1

check_device $dev
state=$?
case $state in
	0)
		echo "Device $dev is fully up to date"
		;;
	1)
		echo "Inventory on $dev is empty. Guessing from CPLD ID"
		default_inv $dev
		;;
	2|3)
		echo "IMPLEMENTME ($state)"
		;;
esac

if [ "${dev}" == "9D" ]; then
    fixup_n32822e_primary "${dev}"
fi
