#!/bin/sh
#######################################
# format inventory template
#
# in inventory template set {function_1(function_argument)|function_2(function_argument)....}
# {} - special characters
# (function_argument) - Optional parameter. The expressions {function()} and {function} are equivalent
# Рarser runs first function, if function returns -1 - run next function.. Continue untill a function call will end with success.
# If no function returns "success" (0) - the parser stops working and gives an error

# Example:
# #POSITION  {POS}
#     - for set value run function
#        POS(function_argument=="", inventory_value=="#POSITION", inventory_type="", help_string="")
#
# #POSITION  {POS} # string help
#     - for set value run function
#        POS(function_argument=="", inventory_value=="#POSITION", inventory_type="", help_string="string help")
#
# [header]
#   serial="{SERIAL|VALUE(1)}" # string help
#     - for set value run function
#        SERIAL(function_argument=="", inventory_value=="serial", inventory_type="header", help_string="string help") or
#        VALUE(function_argument=="1", inventory_value=="serial", inventory_type="header", help_string="string help")
#
# Only one template can be placed in one line.
#  port_map={VALUE(100G_FIBRE)} {VALUE(1G_COPPER)} - Error!
# Two options are possible:
# 1) Create a parser function that will set all values at once
#  port_map={VALUE(100G_FIBRE 1G_COPPER)}   - Valid
# 2) Alternate filling of an array
#  port_map={VALUE(100G_FIBRE)}             - Valid
#  port_map={VALUE(1G_COPPER)}              - Valid
# Special characters can be used in the help line (comments)
#  port_map={VALUE(1G_COPPER)}  # secondary {port item}  - Valid

###########
# inventory value functions
#
# These functions are called when variables are set in inventory template.
# Function names (case-sensitive) are specified in inventory template file.
# Before calling the build of inventory, you need to set some global variables.
#
INV_TEMPLATE_IS_INTERACTIVE=0 #Flag allowing (== 1) functions to interact with the user. Otherwise ==0

INV_TEMPLATE_POSITION="" # Set #POSITION directive
INV_TEMPLATE_SERIAL="" # Set serial value

INV_TEMPLATE_BOARD_ID_VISUAL="" # board id for interact with the user

# Arguments of functions:
#  $1 - function argument
#  $2 - inventory value(directive) name
#  $3 - inventory type
#  $4 - help string

#The result of the function is the string of the variable value set in INV_TEMPLATE_VALUE.
INV_TEMPLATE_VALUE=''

#If the function can not set the value of the variable it returns -1 (otherwise 0)
#All functions can be redefined before the parser is called

# Always successful. Returns an empty string
EMPTY(){
  INV_TEMPLATE_VALUE="";
  return 0
}

# Always successful. Returns an 0
ZERO() {
  INV_TEMPLATE_VALUE="0"
  return 0
}

# Always successful. Returns an $1 (function argument) value
VALUE() {
  INV_TEMPLATE_VALUE="$1"
  return 0
}

# Set #POSITION directive
# Preliminarily, the global variable INV_TEMPLATE_POSITION
POS () {
  if [ -n "$INV_TEMPLATE_POSITION" ]; then
    INV_TEMPLATE_VALUE="$INV_TEMPLATE_POSITION"
    return 0
  fi
  return -1
}

# Set serial value
# Preliminarily, the global variable INV_TEMPLATE_SERIAL
SERIAL () {
  if [ -n "$INV_TEMPLATE_SERIAL" ]; then
    INV_TEMPLATE_VALUE="$INV_TEMPLATE_SERIAL"
    return 0
  fi
  if [ "$INV_TEMPLATE_IS_INTERACTIVE" -eq "1" ]; then
    [ -n "$INV_TEMPLATE_POSITION" ] && echo "CPLD $INV_TEMPLATE_POSITION ($INV_TEMPLATE_BOARD_ID_VISUAL)"
    [ -n "$4" ] && echo "  [${4}]"
    echo -n "  Enter value ${3}.${2}:"
    read value
    while [ -z "$value" ]; do echo -n "Enter:"; read value; done
    INV_TEMPLATE_VALUE="$value"
    return 0
  fi
  return -1
}

serial () {  # traditional name
  if [ -n "$INV_TEMPLATE_SERIAL" ]; then
    INV_TEMPLATE_VALUE="$INV_TEMPLATE_SERIAL"
    return 0
  fi
  if [ "$INV_TEMPLATE_IS_INTERACTIVE" -eq "1" ]; then
    [ -n "$INV_TEMPLATE_POSITION" ] && echo "CPLD $INV_TEMPLATE_POSITION ($INV_TEMPLATE_BOARD_ID_VISUAL)"
    [ -n "$4" ] && echo "  [${4}]"
    echo "  Enter ${3}.${2} value:"
    read value
    while [ -z "$value" ]; do echo -n "Enter:"; read value; done
    INV_TEMPLATE_VALUE="$value"
    return 0
  fi
  return -1
}

#return one from $1 (function argument) list value
#if INV_TEMPLATE_IS_INTERACTIVE==0 return first value
# format $1 (function argument) = "value_default|value_1|.....|value_n"
# in inventory template: ENUM(value_default|value_1|.....|value_n)
ENUM () {
  if [ "$INV_TEMPLATE_IS_INTERACTIVE" -eq "1" ]; then
   [ -n "$INV_TEMPLATE_POSITION" ] && echo "CPLD $INV_TEMPLATE_POSITION ($INV_TEMPLATE_BOARD_ID_VISUAL)"
   echo "  Enter ${3}.${2} value index:"
   [ -n "$4" ] && echo "  [${4}]"
   echo $1 | awk '{split($0, tmp_arr, "|");
                   for (i in tmp_arr){
                     print "\t" i ": " tmp_arr[i];
                   };
                   printf "\t0: Invalid answer!\nEnter [0-" i "]:";
                  }'
   read index
   while [ -z "$index" ]; do echo -n "Enter:"; read index; done
  else
    index=1
  fi
  if [ -n "$index" ]; then
    INV_TEMPLATE_VALUE=`echo $1 | awk '{split($0, tmp_arr, "|");
                                        for (i in tmp_arr){
                                          if(i=="'$index'"){
                                            print tmp_arr[i];
                                            exit 0;
                                          };
                                        };
                                        exit -1
                                       }'`
    return $?
  fi
  return -1
}


###########
# special functions and variables
#

# path to awk skripts
if [ -z $INV_TEMPLATE_SCRIPT_PATH ]; then
  _INV_BASEDIR=`dirname $0`
  INV_TEMPLATE_SCRIPT_PATH=`cd $_INV_BASEDIR; pwd`
fi

if [ ! -f "$INV_TEMPLATE_SCRIPT_PATH/inv_template_write.awk" ] ||
   [ ! -f "$INV_TEMPLATE_SCRIPT_PATH/inv_template_read.awk" ]; then
   echo "Fatal Error!!! The path to awk scripts is not specified correctly [$INV_TEMPLATE_SCRIPT_PATH] " 1>&2
   exit -1
fi

isFunctionDeclare() {
  declare -f "$@" > /dev/null && return 0 || return -1
}


###########
# parse script
#
# arguments
# $1 - template file
# $2 - result file
inv_template_prepare() {
  local line_block_num=0
  local value_set_phase=0 # ==0 - start set global inv_line value, ==1 - start run function, ==2 - set nev inv_line
  local conf_string=""
  local conf_block_type=""
  local conf_help_string=""
  local conf_value_name=""
  local conf_input_file="$1"
  local conf_output_file="$2"
  local conf_current_file="$1"

  if [ -z "$conf_output_file" ]; then
     echo "Fatal Error!!! Not set result file" 1>&2
     return -1
  fi
  if [ -z "$conf_input_file" ]; then
     echo "Fatal Error!!! Not set template file" 1>&2
     return -1
  fi
  if [ "$conf_output_file" = "$conf_input_file" ]; then
     echo "Fatal Error!!! Input and output files must be different" 1>&2
     return -1
  fi
  exec 5<&0
  awk -f $INV_TEMPLATE_SCRIPT_PATH/inv_template_read.awk $conf_input_file | {
    while read line;
    do
      if [ "${line}" = "---" ]; then
        if [ "$value_set_phase" -eq "1" ]; then
          echo "Fatal Error!!! Not set inventory line [type= $conf_block_type, name=$conf_value_name]" 1>&2
          return -1
        fi
        line_block_num=0;
        value_set_phase=0;
        conf_string=""
        conf_block_type=""
        conf_help_string=""
        conf_value_name=""
        continue;
      fi
      line_block_num=`expr $line_block_num + 1`
      case "$line_block_num" in
        "1" )
          conf_string=$line
        ;;
        "2" )
          conf_block_type=$line
        ;;
        "3" )
          conf_help_string=$line
        ;;
        "4" )
          conf_value_name=$line
        ;;
        * )
          if [ "$value_set_phase" -eq "2" ]; then
            continue;
          fi
          value_set_phase=1
          local funk_name=`echo "$line"| cut -d' ' -f 1`
          local funk_arg=`echo "$line"| cut -s -d' ' -f 2-`
          if [ -n "$funk_name" ]; then
            #echo "START: $funk_name ( $funk_arg ), blok: $conf_block_type, help: $conf_help_string, name: $conf_value_name" 1>&2
            isFunctionDeclare $funk_name
            if [ "$?" -ne "0" ]; then
              echo "Warning!!! $value_set_phase function $funk_name() not declare [type= $conf_block_type, name=$conf_value_name]" 1>&2
              continue;
            fi
            exec 6<&0
            exec 0<&5
            $funk_name "$funk_arg" "$conf_value_name" "$conf_block_type" "$conf_help_string"
            local return_funk_name=$?
            exec 0<&6
            if [ "$return_funk_name" -eq "0" ]; then
              local current_file=$(mktemp /tmp/invtmp.XXXXXX)
              awk  -v STR="$conf_string"                               \
                   -v VAL="$INV_TEMPLATE_VALUE"                        \
                   -v TYPE="$conf_block_type"                          \
                   -f $INV_TEMPLATE_SCRIPT_PATH/inv_template_write.awk \
                   $conf_current_file > $current_file
              if [ "$conf_current_file" != "$conf_input_file" ]; then
                rm $conf_current_file
              fi
              if [ ! -f $current_file ]; then
                echo "Fatal Error!!! Can't write tmp inventory file" 1>&2
                return -1
              fi
              conf_current_file=$current_file;
              value_set_phase=2
            fi
          fi
        ;;
      esac
    done
    if [ -n "$conf_current_file" ]; then
      cp $conf_current_file $conf_output_file
      if [ "$conf_current_file" != "$conf_input_file" ]; then
        rm $conf_current_file
      fi
      return  0
    else
      return -1
    fi
  }
  return $?
}

inv_template_clear_gvar(){
  INV_TEMPLATE_POSITION=""
  INV_TEMPLATE_SERIAL=""
  INV_TEMPLATE_BOARD_ID_VISUAL=""
  #TODO: When adding a global variable, do not forget to add it to this function
}

inv_template_set_gvar(){
  INV_TEMPLATE_POSITION=$1
  INV_TEMPLATE_BOARD_ID_VISUAL=$2
  INV_TEMPLATE_SERIAL=$3
}
