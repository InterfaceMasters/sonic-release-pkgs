#!/bin/bash
######################################################################
#
#  INTERFACE MASTERS CONFIDENTIAL & PROPRIETARY
#  __________________
#
#   2017-present Interface Masters Technologies, Inc.
#
#  All information contained herein is
#  the proprietary property of Interface Masters Technologies, Inc.,
#  and are protected by trade secret or copyright law.
#  Dissemination of this information or reproduction of this material
#  is strictly forbidden unless prior written permission is obtained
#  from Interface Masters Technologies.
#
######################################################################

function die() {
	/usr/bin/logger $@
	exit 1
}

dev=$(</sys/${DEVPATH}/sel) || die "Unable to find the selector value for $DEVPATH"

/bin/date >> /tmp/inv-udev-update.log 2>&1
/usr/bin/env >> /tmp/inv-udev-update.log 2>&1

/usr/lib/boardinv/default-inv.sh $dev >> /tmp/inv-udev-update.log 2>&1
